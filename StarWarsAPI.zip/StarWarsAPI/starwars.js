
const axios = require('axios');

// Función para obtener los datos de los personajes de Star Wars
function getStarWarsCharacters() {
  axios.get('https://swapi.dev/api/people/')
    .then(response => {
      console.log('Personajes de Star Wars:');
      console.log('____________________________________')
      response.data.results.forEach(character => {
        console.log('- ' + character.name);
      });    
    })
    .catch(error => {
      console.log('Error:', error);
    });
}

getStarWarsCharacters();




function getStarWarsStarships() {
  axios.get('https://swapi.dev/api/starships/')
    .then(response => {
      const starships = response.data.results;
      console.log('Naves espaciales de Star Wars:');
      starships.forEach(starship => {
        console.log('Nombre:', starship.name);
        console.log('Modelo:', starship.model);
        console.log('Fabricante:', starship.manufacturer);     
        console.log('____________________________________')
      });
    })
    .catch(error => {
      console.error('Error al obtener las naves espaciales de Star Wars:', error);
    });
}
getStarWarsStarships();


// Función para obtener los nombres de los planetas y sus residentes
async function getStarWarsPlanetsAndResidents() {
  try {
    const response = await axios.get('https://swapi.dev/api/planets/');
    const planets = response.data.results;

    console.log('Nombres de los planetas y sus residentes:');
    for (const planet of planets) {
        console.log('Nombre del planeta:', planet.name);
      console.log('Residentes:');

      for (const residentUrl of planet.residents) {
        try {
          const residentResponse = await axios.get(residentUrl);
          const resident = residentResponse.data;
          console.log('- ' + resident.name);
          console.log('____________________________________')
        } catch (error) {
          console.log('Error obteniendo información del residente:', error.message);
        }
      }

    }
  } catch (error) {
    console.log('Error obteniendo información de los planetas:', error.message);
  }
}

getStarWarsPlanetsAndResidents();

