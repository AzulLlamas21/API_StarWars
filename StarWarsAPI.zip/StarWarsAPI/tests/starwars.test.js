const axios = require('axios');
const MockAdapter = require('axios-mock-adapter');
const { getStarWarsCharacters, getStarWarsStarships, getStarWarsPlanetsAndResidents } = require('../main');

describe('Star Wars API Tests', () => {
  let mock;

  beforeEach(() => {
    mock = new MockAdapter(axios);
  });

  afterEach(() => {
    mock.reset();
  });

  afterAll(() => {
    mock.restore();
  });

  it('should fetch and display Star Wars characters', async () => {
    const charactersData = {
      results: [
        { name: 'Luke Skywalker' },
        { name: 'Darth Vader' },
        { name: 'Princess Leia' }
      ]
    };

    mock.onGet('https://swapi.dev/api/people/').reply(200, charactersData);

    const consoleSpy = jest.spyOn(console, 'log');

    await getStarWarsCharacters();

    expect(consoleSpy).toHaveBeenCalledTimes(4); // Incluye el título "Personajes de Star Wars:"
    expect(consoleSpy).toHaveBeenNthCalledWith(2, '- Luke Skywalker');
    expect(consoleSpy).toHaveBeenNthCalledWith(3, '- Darth Vader');
    expect(consoleSpy).toHaveBeenNthCalledWith(4, '- Princess Leia');
  });

  it('should fetch and display Star Wars starships', async () => {
    const starshipsData = {
      results: [
        { name: 'Starship 1', model: 'Model 1', manufacturer: 'Manufacturer 1' },
        { name: 'Starship 2', model: 'Model 2', manufacturer: 'Manufacturer 2' },
      ]
    };

    mock.onGet('https://swapi.dev/api/starships/').reply(200, starshipsData);

    const consoleSpy = jest.spyOn(console, 'log');

    await getStarWarsStarships();

    expect(consoleSpy).toHaveBeenCalledTimes(10); // Incluye el título "Naves espaciales de Star Wars:" y las divisiones "___________________"
    expect(consoleSpy).toHaveBeenNthCalledWith(2, 'Nombre:', 'Starship 1');
    expect(consoleSpy).toHaveBeenNthCalledWith(3, 'Modelo:', 'Model 1');
    expect(consoleSpy).toHaveBeenNthCalledWith(4, 'Fabricante:', 'Manufacturer 1');
    expect(consoleSpy).toHaveBeenNthCalledWith(5, '___________________');
    expect(consoleSpy).toHaveBeenNthCalledWith(6, 'Nombre:', 'Starship 2');
    expect(consoleSpy).toHaveBeenNthCalledWith(7, 'Modelo:', 'Model 2');
    expect(consoleSpy).toHaveBeenNthCalledWith(8, 'Fabricante:', 'Manufacturer 2');
    expect(consoleSpy).toHaveBeenNthCalledWith(9, '___________________');
  });

  it('should fetch and display Star Wars planets and residents', async () => {
    const planetsData = {
      results: [
        { name: 'Planet 1', residents: ['https://swapi.dev/api/people/1/', 'https://swapi.dev/api/people/2/'] },
        { name: 'Planet 2', residents: ['https://swapi.dev/api/people/3/'] },
      ]
    };

    const residentsData = {
      name: 'Resident Name'
    };

    mock.onGet('https://swapi.dev/api/planets/').reply(200, planetsData);
    mock.onGet('https://swapi.dev/api/people/1/').reply(200, residentsData);
    mock.onGet('https://swapi.dev/api/people/2/').reply(200, residentsData);
    mock.onGet('https://swapi.dev/api/people/3/').reply(200, residentsData);

    const consoleSpy = jest.spyOn(console, 'log');

    await getStarWarsPlanetsAndResidents();

    expect(consoleSpy).toHaveBeenCalledTimes(9); // Incluye el título "Nombres de los planetas y sus residentes:" y las divisiones "___________________________________"
    expect(consoleSpy).toHaveBeenNthCalledWith(2, 'Nombre del planeta:', 'Planet 1');
    expect(consoleSpy).toHaveBeenNthCalledWith(3, 'Residentes:');
    expect(consoleSpy).toHaveBeenNthCalledWith(4, '- Resident Name');
    expect(consoleSpy).toHaveBeenNthCalledWith(5, '___________________________________');
    expect(consoleSpy).toHaveBeenNthCalledWith(6, 'Nombre del planeta:', 'Planet 2');
    expect(consoleSpy).toHaveBeenNthCalledWith(7, 'Residentes:');
    expect(consoleSpy).toHaveBeenNthCalledWith(8, '- Resident Name');
    expect(consoleSpy).toHaveBeenNthCalledWith(9, '___________________________________');
  });
});
